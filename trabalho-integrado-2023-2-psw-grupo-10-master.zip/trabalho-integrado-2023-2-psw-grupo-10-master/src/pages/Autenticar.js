import { connect } from 'react-redux';
import { reduxForm, Field } from 'redux-form'
import React from 'react'
import { submitUserAction } from '../actions/authActions';

const Autenticar = props => {
    const { handleSubmit } = props

    const submit = (data, submitUserAction) => {
        submitUserAction(data)
        console.log(data);
    }

    return (
        <form onSubmit={handleSubmit((fields) => submit(fields, submitUserAction))}>
            {/*  <label>
                Nome
            </label>

            <Field name="nome" component="input" type="text" />
 */}
            <label>
                Email
            </label>

            <Field name="email" component="input" type="text" />
            <br />
            <label>
                Senha
            </label>

            <Field name="senha" component="input" type="passowd" />
            <br />
            <button type='submit' name='Enviar' title='Envie agora'>
                Enviar
            </button>
            <br />
        </form>
    )
}

const UserForm = reduxForm({
    form: 'formUser'
})(Autenticar);

const mapState = state => {
    return { item: state.item };
}

export default connect(mapState, submitUserAction)(UserForm);