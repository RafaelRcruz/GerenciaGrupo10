const BASE_URL = 'http://localhost:3001';

export {
    BASE_URL
}