export interface dados {
    id?: number,
	name?: string,
    email?: string,
    senha?: string,
}