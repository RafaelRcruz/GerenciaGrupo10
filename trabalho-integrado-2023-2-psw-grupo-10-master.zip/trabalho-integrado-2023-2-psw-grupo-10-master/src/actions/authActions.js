import { BASE_URL } from "../../src/services/api"
import axios from 'axios';
import setAuthToken from '../utils/setAuthToken';
import { FETCH_DATA_SUCCESS } from '../actions/types';
import { jwtDecode } from "jwt-decode";

export const submitUserAction = (userData) => (dispatch) => {
    console.log(userData);
    axios.post(BASE_URL + '/login', userData)
        .then((res) => {
            const { token } = res.data;
            localStorage.setItem('jwtToken', token);
            setAuthToken(token);
            const decoded = jwtDecode(token);
            dispatch(setCurrentUser(decoded));
        })
        .catch((err) => {
            console.error(err);
        });
}
export const setCurrentUser = (decoded) => {
    return {
        type: FETCH_DATA_SUCCESS,
        payload: decoded,
    };
};


