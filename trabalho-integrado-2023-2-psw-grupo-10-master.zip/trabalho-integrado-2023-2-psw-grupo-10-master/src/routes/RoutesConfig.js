import AboutUs from "../pages/About Us";
import ContactUs from "../pages/Contact Us";
import Service from "../pages/Service";
import Home from "../pages/Home";
import Autenticar from "../pages/Autenticar";

const routesConfig = [
    {
        id: 1,
        path: "/about-Us",
        component: AboutUs,
        exact: true
    }, {
        id: 2,
        path: "/contact-Us",
        component: ContactUs,
        exact: true
    }, {
        id: 3,
        path: "/service",
        component: Service,
        exact: true
    },
    {
        id: 4,
        path: "/",
        component: Home,
        exact: true
    }, {
        id: 5,
        path: "/auth",
        component: Autenticar,
        exact: true
    },

]

export default routesConfig