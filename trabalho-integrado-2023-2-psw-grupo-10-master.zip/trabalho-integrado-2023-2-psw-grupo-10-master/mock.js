
export const users = [
    {
        "id": 1,
        "nome": "Usuário 1",
        "email": "usuario1@email.com",
        "senha": "senha123"
    },
    {
        "id": 2,
        "nome": "Usuário 2",
        "email": "usuario2@email.com",
        "senha": "senha456"
    }
];
export const posts = [];